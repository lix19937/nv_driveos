/*Maps current topic to its parent: "topicIndex:parentIndex". -1 represents the map.*/
define(function () {
return {12:-1,9:-1,8:4,7:4,10:4,11:-1,5:-1,1:-1,4:-1,6:4,0:4,2:4};
});