define(function() {var keywords=[{w:"NVIDIA",p:["p0","p1","p2","p5","p9","p10","p11","p13","p14","p15","p16","p17","p18","p19","p20","p21"]},{w:"DRIVE",p:["p0","p1","p2","p5"]},{w:"OS",p:["p0"]},{w:"SDK",p:["p1","p4"]},{w:"ORIN",p:["p2"]},{w:"Autonomous",p:["p3"]},{w:"Vehicles",p:["p3"]},{w:"Manager",p:["p4"]},{w:"AGX",p:["p5"]},{w:"System",p:["p6"]},{w:"Installation",p:["p6"]},{w:"CUDA",p:["p7"]},{w:"TensorRT",p:["p8"]},{w:"DP-MST",p:["p9"]},{w:"Display",p:["p9","p19"]},{w:"|",p:["p9","p10","p11","p13","p14","p15","p16","p17","p18","p19","p20","p21"]},{w:"Docs",p:["p9","p10","p11","p13","p14","p15","p16","p17","p18","p19","p20","p21"]},{w:"Legal",p:["p10"]},{w:"Information",p:["p10"]},{w:"SC7",p:["p11"]},{w:"Context",p:["p12"]},{w:"Sensitive",p:["p12"]},{w:"Help",p:["p12"]},{w:"Features",p:["p13"]},{w:"Getting",p:["p14"]},{w:"Started",p:["p14"]},{w:"with",p:["p14"]},{w:"the",p:["p14"]},{w:"NvSIPL",p:["p14","p18"]},{w:"Multicast",p:["p14","p18"]},{w:"Sample",p:["p14","p18"]},{w:"Inference",p:["p15"]},{w:"Task",p:["p15"]},{w:"Late",p:["p16"]},{w:"Attach",p:["p16"]},{w:"Peer",p:["p17"]},{w:"Validation",p:["p17"]},{w:"Understanding",p:["p18"]},{w:"Stitching",p:["p19"]},{w:"and",p:["p19"]},{w:"Usage",p:["p20"]},{w:"Versions",p:["p21"]}];
var ph={};
ph["p0"]=[0, 1, 2];
ph["p1"]=[0, 1, 3];
ph["p2"]=[0, 1, 4];
ph["p3"]=[5, 6];
ph["p4"]=[3, 7];
ph["p5"]=[0, 1, 8];
ph["p6"]=[9, 10];
ph["p7"]=[11];
ph["p8"]=[12];
ph["p9"]=[13, 14, 15, 0, 16];
ph["p10"]=[17, 18, 15, 0, 16];
ph["p21"]=[41, 15, 0, 16];
ph["p20"]=[40, 15, 0, 16];
ph["p12"]=[20, 21, 22];
ph["p11"]=[19, 15, 0, 16];
ph["p14"]=[24, 25, 26, 27, 28, 29, 30, 15, 0, 16];
ph["p13"]=[23, 15, 0, 16];
ph["p16"]=[33, 34, 15, 0, 16];
ph["p15"]=[31, 32, 15, 0, 16];
ph["p18"]=[37, 28, 29, 30, 15, 0, 16];
ph["p17"]=[35, 36, 15, 0, 16];
ph["p19"]=[38, 39, 14, 15, 0, 16];
     return {
         keywords: keywords,
         ph: ph
     }
});
